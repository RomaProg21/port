<?php
$connect = mysqli_connect("localhost", "root", "", "users2");
if (!$connect) {
   die('Ошибка!');
}
?>
