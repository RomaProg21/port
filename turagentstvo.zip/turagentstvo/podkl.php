<?php
$podkl = mysqli_connect("localhost", "root", "", "users3");
if (!$podkl) {
   die('Сбой');
}
?>
