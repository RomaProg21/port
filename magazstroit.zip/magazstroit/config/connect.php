<?php
$mysqli = mysqli_connect("localhost", "root", "", "Magaz");
if (!$mysqli) {
   die('Ошибка!');
}
?>
